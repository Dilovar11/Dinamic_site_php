<?php 
include("../../path.php"); 
include("../../app/database/db.php"); 
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Freelance.tj</title>
    <link href="../../bootstrap_5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
  </head>

  <body>

    <!----------------------------------------- ХИДДЕР СТРАНИЦЫ ------------------------------------------------> 

    <?php include("../../app/include/header_admin.php"); ?>

    <!----------------------------------------- БЛОК СТРАНИЦЫ ------------------------------------------------> 

    
    <div class="container">
        <div class="row">
            <div class="sidebar col-3">
                <ul>
                    <li>
                        <a href="">Записи</a>
                    </li>
                    <li>
                        <a href="">Пользователи</a>
                    </li>
                    <li>
                        <a href="">Категории</a>
                    </li>
                </ul>
            </div>
            <div class="posts col-9">
                <div class="row title-table">
                    <h2>Добавление записи</h2>
                    <div class="button row">
                    <a href="create.php" class="col-3 btn btn-success">Создать публикацию</a>
                    <a href="index.php" class="col-3 btn btn-warning">Редактировать публикацию</a>
                </div>
                </div>
                <div class="row add-post">
                    <form action="create.php" method="Post">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="title" aria-label="Название статьи">
                        </div>
                        <div class="col">
                            <label for="content" class="form-label">Содержимое записи</label>
                            <textarea name="" class="form-control" id="content" rows="6"></textarea>
                        </div>
                        <div class="input-group mb-3">
                            <input type="file" class="form-control" id="inputGroupFile02">
                            <label class="input-group-text" for="inputGroupFile02">Upload</label>
                        </div>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <div class="col">
                            <button class="btn btn-primary" type="submit">Сохранить запись</button>
                        </div>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
    





    <script src="../../bootstrap_5.3.2/js/bootstrap.bundle.min.js"></script>
  </body>
</html>