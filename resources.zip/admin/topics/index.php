<?php 
include("../../path.php"); 
include("../../app/database/db.php"); 
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Freelance.tj</title>
    <link href="../../bootstrap_5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
  </head>

  <body>

    <!----------------------------------------- ХИДДЕР СТРАНИЦЫ ------------------------------------------------> 

    <?php include("../../app/include/header_admin.php"); ?>

    <!----------------------------------------- БЛОК СТРАНИЦЫ ------------------------------------------------> 

    
    <div class="container">
        <div class="row">
            <div class="sidebar col-3">
                <ul>
                    <li>
                        <a href="">Записи</a>
                    </li>
                    <li>
                        <a href="">Пользователи</a>
                    </li>
                    <li>
                        <a href="">Категории</a>
                    </li>
                </ul>
            </div>
            <div class="posts col-9">
                <div class="button row">
                    <a href="create.php" class="col-3 btn btn-success">Создать категорию</a>
                    <a href="index.php" class="col-3 btn btn-warning">Управлять категориями</a>
                </div>
                <div class="row title-table">
                    <h2>Управление категориями</h2>
                    <div class="id col-1">ID</div>
                    <div class="title col-5">Название</div>
                    <div class="red col-4">Управление</div>

                </div>
                <div class="row post">
                    <div class="id col-1">1</div>
                    <div class="title col-5">Путешествие</div>
                    <div class="red col-2"><a href="">edit</a></div>
                    <div class="del col-2"><a href="">delete</a></div>
                </div>
                
            </div>
        </div>
    </div>
    





    <script src="../../bootstrap_5.3.2/js/bootstrap.bundle.min.js"></script>
  </body>
</html>