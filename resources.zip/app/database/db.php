<?php 

session_start();
require("connect.php");


// ПРОВЕРКА ПОЛУЧЕНИЕ ДАННЫХ ИЗ ТАБЛИЦЫ
function dbCheckError($query){
    $errorInfo = $query -> errorInfo();

    if($errorInfo[0]!==PDO::ERR_NONE){
        echo $errorInfo[2];
        exit();
    }
    return true;
}


// ЗАПРОС НА ПОЛУЧЕНИЕ ДАННЫХ С ОДНОЙ ТАБЛИЦЫ
function selectAll($table, $params=[]){
    global $connection;
    $sql = "SELECT * FROM $table";
    if(!empty($params)){
        $i = 0;
        foreach($params as $key => $value){
            if (!is_numeric($value)){
                $value = "'" . $value . "'";
            }
            if($i === 0){
                $sql = $sql . " WHERE $key = $value";
            }
            else{
                $sql = $sql . " AND $key = $value";
            }
            $i++;
        }
    }
    $query = $connection -> prepare($sql);
    $query -> execute();
    dbCheckError($query);
    return $query -> fetchAll();
}

// ЗАПРОС НА ПОЛУЧЕНИЕ ДАННЫХ ОДНОЙ СТРОКИ ИЗ ВЫБРАННОЙ ТАБЛИЦЫ
function selectOne($table, $params=[]){
    global $connection;
    $sql = "SELECT * FROM $table";
    if(!empty($params)){
        $i = 0;
        foreach($params as $key => $value){
            if (!is_numeric($value)){
                $value = "'" . $value . "'";
            }
            if($i === 0){
                $sql = $sql . " WHERE $key = $value";
            }
            else{
                $sql = $sql . " AND $key = $value";
            }
            $i++;
        }
    }
    //$sql = $sql . " LIMIT 1";
    $query = $connection -> prepare($sql);
    $query -> execute();
    dbCheckError($query);
    return $query -> fetch();
}


// ЗАПИСЬ В ТАБЛИЦУ БД
function insert($table, $params){
    global $connection;
    //INSERT INTO users (admin, username, email, password, created) VALUES ('0', 'test', 'test@gmail.com', '2323', CURRENT_TIMESTAMP); 
    $i = 0;
    $coll = '';
    $mask = '';
    foreach ($params as $key => $value){
        if($i===0){
            $coll = $coll . "$key";
            $mask = $mask . "'" . "$value" . "'"; 
        }
        else{
            $coll = $coll . ", $key";
            $mask = $mask . ", '" .  "$value" . "'"; 
        }
        $i++;
    }

    $sql = "INSERT INTO $table ($coll) VALUES ($mask)";
    $query = $connection -> prepare($sql);
    $query -> execute($params);
    dbCheckError($query);
    return $connection -> lastInsertId();
}


// ОБНАВЛЕНИЕ ДАННЫХ ТАБЛИЦЫ БД
function update($table, $id, $params){
    global $connection;
    //UPDATE `users` SET admin = '1', password = 'sddrr3333'  WHERE id = '1'; 
    $i = 0;
    $str = '';
    foreach ($params as $key => $value){
        if($i===0){
            $str = $str . $key ." = '" . $value . "'"; 
        }
        else{
            $str = $str . ", " . $key ." = '" . $value . "'"; 
        }
        $i++;
    }
    $sql = "UPDATE $table SET $str WHERE id = $id";
    $query = $connection -> prepare($sql);
    $query -> execute($params);
    dbCheckError($query);
}



// УДАЛЕНИЕ СТРОКИ ТАБЛИЦЫ БД ПО ID
function delete($table, $id){
    global $connection;
    //DELETE FROM user WHERE id = 1;
    $sql = "DELETE FROM $table WHERE id = $id";
    $query = $connection -> prepare($sql);
    $query -> execute();
    dbCheckError($query);
}

delete('users',2);
?>