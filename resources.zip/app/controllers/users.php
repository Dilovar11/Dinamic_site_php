<?php

    include "app/database/db.php"; 


    $errMsg = "";
    $login = "";
    $email = "";

    if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['btn-registration']))
    {
        //echo 'post';
        $admin = 0;
        $login = trim($_POST['login']);
        $email = trim($_POST['email']);
        $password_1 = trim($_POST['password_1']);
        $password_2 = trim($_POST['password_2']);


        if ($login === "" || $email === "" || $password_2 ==="")
        {
            $errMsg = "Не вся поля заполнены!";
        }
        elseif (mb_strlen($login, 'UTF8') < 2)
        {
            $errMsg = "Логин должен быть более 2-x символов!";
        }
        elseif ($password_1!==$password_2)
        {
            $errMsg = "Пароли в обеих полях должны соответствовать!";
        }
        else
        {
            $existence = [];
            $existence = selectOne('users', ['email' => $email]);
            if ($existence && isset($existence['email']) && $existence['email'] == $email)
            {
                $errMsg = "Пользователь с такой почтой уже существует!";
            }
            else
            {
                $password = password_hash($password_2, PASSWORD_DEFAULT);
                $post = [
                    'admin' => $admin,
                    'username' => $login,
                    'email' => $email,
                    'password' => $password
                ]; 
                
                $id = insert('users', $post); 
                //$errMsg = "Пользователь " . "<strong>" . $login . "</strong>" .  " успешно зарегистрирован!";
                $user = selectOne('users', ['id' => $id]);
                $_SESSION['id'] = $user['id'];
                $_SESSION['login'] = $user['username'];
                $_SESSION['admin'] = $user['admin'];

                if ($_SESSION['admin']){
                    header('location: ' . BASE_URL . 'admin/admin.php');
                }
                else{
                    header('location: ' . BASE_URL);
                }

            }

        }

    }
    else{
        $login = "";
        $email = "";
    }
    

    //КОД ДЛЯ ФОРМЫ ВХОДА

    if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['btn-login'])){

        $email = trim($_POST['email']);
        $password_1 = trim($_POST['password_1']);

        if ($email === "" || $password_1 === "")
        {
            $errMsg = "Не вся поля заполнены!";
        }
        else
        {
            $existence = selectOne('users', ['email' => $email]);
            if ($existence && password_verify($password_1, $existence['password'])){

                $_SESSION['id'] = $existence['id'];
                $_SESSION['login'] = $existence['username'];
                $_SESSION['admin'] = $existence['admin'];

                if ($_SESSION['admin']){
                    header('location: ' . BASE_URL . 'admin/admin.php');
                }
                else{
                    header('location: ' . BASE_URL);
                }
            }
            else
            {
                $errMsg = "Почта или пароль введены неверно!";
            } 
        }
    }
    else
    {
        $email = "";
    }


        
     
  


    




    


?>