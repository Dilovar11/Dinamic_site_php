<header class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-4">
                <a href="<?php echo BASE_URL ?>">
                    <img src="../../assets/images/default-logo.png" class="logo" alt="...">
                </a>
            </div>
            <nav class="col-8">
                <ul>
                    <?php if(isset($_SESSION['id'])): ?>
                        <a href="#"> 
                            <?php echo $_SESSION['login']; ?>
                        </a>
                        <ul>
                            <li><a href="<?php echo BASE_URL . "logout.php"; ?>">Выход</a></li>
                        </ul>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>