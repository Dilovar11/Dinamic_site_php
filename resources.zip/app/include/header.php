<header class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-4">
                <a href="<?php echo BASE_URL ?>">
                    <img src="assets/images/default-logo.png" class="logo" alt="...">
                </a>
            </div>
            <nav class="col-8">
                <ul>
                    <li>
                        <i class="fa fa-user"></i>
                        <a href="<?php echo BASE_URL . 'job.php' ?>">Работа</a>
                        <ul>
                            <li><a href="<?php echo BASE_URL . 'programming.php' ?>">Программирование</a></li>
                            <li><a href="<?php echo BASE_URL . 'bugalter.php' ?>">Бугалтерия</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo BASE_URL . 'freelancers.php' ?>">Фрилансеры</a></li>
                    <li><a href="<?php echo BASE_URL . 'vacancies.php' ?>">Ваканции</a></li>
                    <li><a href="<?php echo BASE_URL . 'search.php' ?>">Поиск</a></li>
                    <li>
                        <i class="fa fa-user"></i>
                        <a href="<?php echo BASE_URL . 'more.php' ?>">Ещё</a>
                        <ul>
                            <li><a href="#">KKK</a></li>
                            <li><a href="#">HHH</a></li>
                        </ul>
                    </li>
                    <li>
                        <?php if(isset($_SESSION['id'])): ?>
                            <a href="#">
                                <?php echo $_SESSION['login']; ?>
                            </a>
                            <ul>
                            <?php if ($_SESSION['admin']): ?>
                                <li><a href="#">Админ панел</a></li>
                            <?php endif; ?>
                                <li><a href="<?php echo BASE_URL . "logout.php"; ?>">Выход</a></li>
                            </ul>
                        <?php else: ?>
                            <a href="<?php echo BASE_URL . "login.php"; ?>">Вход</a>
                            <ul>
                                <li><a href="<?php echo BASE_URL . "registration.php"; ?>">Регистрация</a></li>
                            </ul>
                        <?php endif; ?>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>